package tp1.p3.control.exceptions;

public class NotEnoughCoinsException extends GameException{

	public NotEnoughCoinsException(String message) {
		super(message);
	}

}
