package tp1.p3.control.exceptions;

public class NotCatchablePositionException extends InvalidPositionException{

	public NotCatchablePositionException(String message) {
		super(message);
	}

	
}
