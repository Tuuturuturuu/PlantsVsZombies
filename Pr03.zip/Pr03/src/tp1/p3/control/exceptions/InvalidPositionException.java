package tp1.p3.control.exceptions;

public class InvalidPositionException extends GameException {

	public InvalidPositionException(String message) {
		super(message);
		
	}

}
