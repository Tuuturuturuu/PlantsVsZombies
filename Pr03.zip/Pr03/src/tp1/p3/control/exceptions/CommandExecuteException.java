package tp1.p3.control.exceptions;

public class CommandExecuteException extends GameException {

	public CommandExecuteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
