package tp1.p3.logic.actions;

import tp1.p3.logic.GameWorld;

public interface GameAction {
	void execute(GameWorld game);
	
}
